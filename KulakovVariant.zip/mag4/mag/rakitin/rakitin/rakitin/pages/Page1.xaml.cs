﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using rakitin.classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace rakitin.pages
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = ученыеEntities.Getученые().ученые.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPage((sender as Button).DataContext as ученые));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPage(null));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                ученыеEntities.Getученые().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridUsers.ItemsSource = ученыеEntities.Getученые().ученые.ToList();
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            {
                var usersForRemoving = DGridUsers.SelectedItems.Cast<ученые>().ToList();
                if (MessageBox.Show($"Удалить {usersForRemoving.Count()} пользователей?", "Внимание!",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    try
                    {
                        ученыеEntities.Getученые().ученые.RemoveRange(usersForRemoving);
                        ученыеEntities.Getученые().SaveChanges();
                        MessageBox.Show("Данные удалены");
                        DGridUsers.ItemsSource = ученыеEntities.Getученые().ученые.ToList();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }

            }
        }



        private void FiltrName_SecectionChanged(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void RbUP_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = ученыеEntities.Getученые().ученые.OrderBy(x => x.FirstName).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = ученыеEntities.Getученые().ученые.OrderByDescending(x => x.FirstName).ToList();
        }

        private void FindName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DGridUsers.ItemsSource != null)
            {
                DGridUsers.ItemsSource = ученыеEntities.Getученые().ученые.Where(x => x.FirstName.ToLower().Contains(FindName.Text.ToLower())).ToList();
            }
            if (FindName.Text.Count() == 0) DGridUsers.ItemsSource = ученыеEntities.Getученые().ученые.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new List());
        }


        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "№";
            worksheet.Cells[2][IndexRows] = "Фамилия";
            worksheet.Cells[3][IndexRows] = "Учёная степень";
            worksheet.Cells[4][IndexRows] = "Название проекта";
            Excel.Range HeaderRange = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[4][1]];
            HeaderRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            HeaderRange.Font.Bold = true;
            HeaderRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            HeaderRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

            List<ученые> printItems = new List<ученые>();
            for (int i = 0; i < DGridUsers.Items.Count; i++) printItems.Add((ученые)DGridUsers.Items[i]);
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.FirstName;
                worksheet.Cells[3][IndexRows + 1] = item.AcademicDegree;
                worksheet.Cells[4][IndexRows + 1] = item.TopicOfTheReport;
                IndexRows++;

                Excel.Range bodyrange = worksheet.Range[worksheet.Cells[1][IndexRows], worksheet.Cells[4][IndexRows]];
                bodyrange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                bodyrange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                bodyrange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                Excel.Range numbersrange = worksheet.Range[worksheet.Cells[2][1], worksheet.Cells[IndexRows, 1]];
                numbersrange.Font.Italic = true;
            }
            worksheet.Name = "Список учёных";
            worksheet.Columns.AutoFit();
            worksheet.Rows.AutoFit();
            app.Visible = true;
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printObj = new PrintDialog();
            if (printObj.ShowDialog() == true)
            {
                printObj.PrintVisual(DGridUsers, "");
            }
            else
            {
                MessageBox.Show(
                    "Польщователь прервал печать",
                    "Уведомление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                    );
                return;
            }
        }
    }
}

            