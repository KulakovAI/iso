﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using rakitin.classes;

namespace rakitin.pages
{
    /// <summary>
    /// Логика взаимодействия для AddListView.xaml
    /// </summary>
    public partial class AddListView : Page
    {
        public AddListView()
        {
            InitializeComponent();
            LTV.ItemsSource = ученыеEntities.Getученые().ученые.ToList();
        }
        private void MenuAddMechanic_Click(object sender, RoutedEventArgs e)
        {
            classes.ClassFrame.frmObj.Navigate(new AddEditPage(null));
        }

        private void MenuEditMechanic_Click(object sender, RoutedEventArgs e)
        {
            classes.ClassFrame.frmObj.Navigate(new AddEditPage((ученые)LTV.SelectedItem));

        }

        private void MenuDelMechanic_Click(object sender, RoutedEventArgs e)
        {
            var ученыеForRemoving = LTV.SelectedItems.Cast<ученые>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {ученыеForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ученыеEntities.Getученые().ученые.RemoveRange(ученыеForRemoving);
                    ученыеEntities.Getученые().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    LTV.ItemsSource = ученыеEntities.Getученые().ученые.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }


        private void MenuWordMechanic_Click(object sender, RoutedEventArgs e)
        {
            var app = new Word.Application();
            Word.Document document = app.Documents.Add();
            List<ученые> printItems = new List<ученые>();
            for (int i = 0; i < LTV.Items.Count; i++) printItems.Add((ученые)LTV.Items[i]);

            int j = 0;

            Word.Paragraph tableParagraph = document.Paragraphs.Add();
            Word.Range tableRange = tableParagraph.Range;
            Word.Table table = document.Tables.Add(tableRange, printItems.Count() + 1, 5);
            table.Borders.InsideLineStyle = table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
            table.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

            foreach (var item in printItems)
            {
                Word.Range cellRange;

                cellRange = table.Cell(1, 1).Range;
                cellRange.Text = "Фото Ученого";
                cellRange = table.Cell(1, 2).Range;
                cellRange.Text = "Фамилия";
                cellRange = table.Cell(1, 3).Range;
                cellRange.Text = "Учёная степень";
                cellRange = table.Cell(1, 4).Range;
                cellRange.Text = "Название проекта";
                
                table.Rows[1].Range.Bold = 1;
                table.Rows[1].Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                table.Range.Columns[1].Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalBottom;

                cellRange = table.Cell(j + 2, 1).Range;
                Word.InlineShape imageShare = cellRange.InlineShapes.AddPicture(AppDomain.CurrentDomain.BaseDirectory + "..\\..\\" + item.Photo);
                imageShare.Width = imageShare.Height = 80;
                cellRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;

                cellRange = table.Cell(j + 2, 2).Range;
                cellRange.Text = item.FirstName;

                cellRange = table.Cell(j + 2, 3).Range;
                cellRange.Text = item.AcademicDegree;

                cellRange = table.Cell(j + 2, 4).Range;
                cellRange.Text = item.TopicOfTheReport;
                j++;
            }
            app.Visible = true;

        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printObj = new PrintDialog();
            if (printObj.ShowDialog() == true)
            {
                printObj.PrintVisual(LTV, "");
            }
            else
            {
                MessageBox.Show(
                    "Пользователь прервал печать",
                    "Уведомление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                    );
                return;
            }
        }

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int IndexRows = 1;
            worksheet.Cells[1][IndexRows] = "№";
            worksheet.Cells[2][IndexRows] = "Фамилия";
            worksheet.Cells[3][IndexRows] = "Учёная степень";
            worksheet.Cells[4][IndexRows] = "Название проекта";
            Excel.Range HeaderRange = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[4][1]];
            HeaderRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            HeaderRange.Font.Bold = true;
            HeaderRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            HeaderRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

            List<ученые> printItems = new List<ученые>();
            for (int i = 0; i < LTV.Items.Count; i++) printItems.Add((ученые)LTV.Items[i]);
            foreach (var item in printItems)
            {
                worksheet.Cells[1][IndexRows + 1] = IndexRows;
                worksheet.Cells[2][IndexRows + 1] = item.FirstName;
                worksheet.Cells[3][IndexRows + 1] = item.AcademicDegree;
                worksheet.Cells[4][IndexRows + 1] = item.TopicOfTheReport;
                IndexRows++;

                Excel.Range bodyrange = worksheet.Range[worksheet.Cells[1][IndexRows], worksheet.Cells[4][IndexRows]];
                bodyrange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                bodyrange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                bodyrange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                Excel.Range numbersrange = worksheet.Range[worksheet.Cells[2][1], worksheet.Cells[IndexRows, 1]];
                numbersrange.Font.Italic = true;
            }
            worksheet.Name = "Список учёных";
            worksheet.Columns.AutoFit();
            worksheet.Rows.AutoFit();
            app.Visible = true;
        }
    }
}

