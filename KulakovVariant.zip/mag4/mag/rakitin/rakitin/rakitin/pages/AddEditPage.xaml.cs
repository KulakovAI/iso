﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace rakitin.pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
    public partial class AddEditPage : Page
    {
        private ученые _ученые = new ученые();//новое поле, которое будет хранить в себе экземпляр пользователя
        public AddEditPage(ученые selectedPerson)// объект selectedPerson
        {
            InitializeComponent();
            if (selectedPerson != null)
                _ученые = selectedPerson;
            DataContext = _ученые; // Созданный контекст
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();//Объект ошибка

            if (string.IsNullOrWhiteSpace(_ученые.FirstName))
                error.AppendLine("Укажите фамилию");
            if (string.IsNullOrWhiteSpace(_ученые.AcademicDegree))
                error.AppendLine("Укажите учёную степень");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //Если пользователь новый
            if (_ученые.Id == 0)
                ученыеEntities.Getученые().ученые.Add(_ученые);//Добавить его 
            try
            {
                ученыеEntities.Getученые().SaveChanges(); //Сохранить изменения
                MessageBox.Show("Данные сохранены");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
    }

